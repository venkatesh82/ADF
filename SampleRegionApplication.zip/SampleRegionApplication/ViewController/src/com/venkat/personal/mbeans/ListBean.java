package com.venkat.personal.mbeans;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.layout.RichPanelTabbed;
import oracle.adf.view.rich.component.rich.layout.RichShowDetailItem;
import oracle.adf.view.rich.context.AdfFacesContext;

public class ListBean {
    private RichPanelTabbed panelTabBind;
    private RichShowDetailItem listShowDetail;

    public ListBean() {
    }

    public void openApplication(ActionEvent actionEvent) {
        // Add event code here...
        MultiTaskFlowBinding m=this.lookupMultiTaskFlowBinding();
        m.refreshTaskFlowBinding();
        AdfFacesContext.getCurrentInstance().addPartialTarget(getPanelTabBind());
        this.getListShowDetail().setDisclosed(false);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getListShowDetail());

    }
    private MultiTaskFlowBinding lookupMultiTaskFlowBinding() {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ELContext elctx = fctx.getELContext();
        Application app = fctx.getApplication();
        ExpressionFactory exprFactory = app.getExpressionFactory();

        ValueExpression ve =
            exprFactory.createValueExpression(elctx, "#{viewScope.MultiTaskFlowBinding}", Object.class);
        MultiTaskFlowBinding mtb = (MultiTaskFlowBinding) ve.getValue(elctx);

        return mtb;
    }

    public void setPanelTabBind(RichPanelTabbed panelTabBind) {
        this.panelTabBind = panelTabBind;
    }

    public RichPanelTabbed getPanelTabBind() {
        return panelTabBind;
    }

    public void setListShowDetail(RichShowDetailItem listShowDetail) {
        this.listShowDetail = listShowDetail;
    }

    public RichShowDetailItem getListShowDetail() {
        return listShowDetail;
    }
}
