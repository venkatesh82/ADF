package com.venkat.personal.mbeans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.controller.binding.TaskFlowBindingAttributes;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

public class MultiTaskFlowBinding {
    
    //The list of task flow definitions that is displayed as dynamic regions
    private List<TaskFlowBindingAttributes> multiTaskFlowBindings = new ArrayList<TaskFlowBindingAttributes>();
    private HashMap<String,Object> tfParams=null;
    private boolean taskFlowBindingsEmpty = true;
    
    
    public MultiTaskFlowBinding() {
        super();
    }


    public void refreshTaskFlowBinding(){
        multiTaskFlowBindings=this.getMultiTaskFlowBindings();
        TaskFlowBindingAttributes taskFlowBindingAttributes = new TaskFlowBindingAttributes();
        taskFlowBindingAttributes.setId("ID_" +(int) Math.floor(Math.random()*10));
        taskFlowBindingAttributes.setTaskFlowId(new TaskFlowId("/WEB-INF/EmployeeTF.xml",
                                                               "EmployeeTF"));
        tfParams=new HashMap<String,Object>();
        
        BindingContext context=BindingContext.getCurrent();
        DCBindingContainer container = (DCBindingContainer) context.getCurrentBindingsEntry();
        DCIteratorBinding itr=container.findIteratorBinding("EmployeesView1Iterator");
        Integer employeeId = (Integer) itr.getCurrentRow().getAttribute("EmployeeId");
        tfParams.put("empId", employeeId);
        taskFlowBindingAttributes.setParametersMap("#{viewScope.MultiTaskFlowBinding.tfParams}");
        
        multiTaskFlowBindings.add(taskFlowBindingAttributes);
        

    }
    public void setMultiTaskFlowBindings(List<TaskFlowBindingAttributes> multiTaskFlowBindings) {
        this.multiTaskFlowBindings = multiTaskFlowBindings;
    }

    public List<TaskFlowBindingAttributes> getMultiTaskFlowBindings() {
        return multiTaskFlowBindings;
    }

    public void setTaskFlowBindingsEmpty(boolean taskFlowBindingsEmpty) {
        this.taskFlowBindingsEmpty = taskFlowBindingsEmpty;
    }

    public boolean isTaskFlowBindingsEmpty() {
        return taskFlowBindingsEmpty;
    }

    public void setTfParams(HashMap<String, Object> tfParams) {
        this.tfParams = tfParams;
    }

    public HashMap<String, Object> getTfParams() {
        return tfParams;
    }
}
