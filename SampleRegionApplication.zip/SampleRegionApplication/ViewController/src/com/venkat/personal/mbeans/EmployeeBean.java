package com.venkat.personal.mbeans;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.server.ViewObjectImpl;

public class EmployeeBean {
    public EmployeeBean() {
    }

    public void executeCriteria(Integer id) {
        // Add event code here...
        System.out.println(id+"----->id");
        if(id>0){
            BindingContext context=BindingContext.getCurrent();
            DCBindingContainer container = (DCBindingContainer) context.getCurrentBindingsEntry();
            DCIteratorBinding itr=container.findIteratorBinding("EmployeesView1Iterator");
            ViewObjectImpl vo = (ViewObjectImpl) itr.getViewObject();
            ViewCriteria vc=vo.getViewCriteria("EmployeesViewCriteria");
            vo.applyViewCriteria(vc);
            vo.setNamedWhereClauseParam("employeeBind", id);
            vo.executeQuery();
        }
    }
}
